Directories & Files Listing:
ana_code
• "Crime Subway Distance Calc.txt" - impala shell code that reads in cleaned datasets from MR programs, calculates distance to nearest rail station as well as which station was closest, and saves a table view in Impala of a lookup containing this information
• "Impala Crime Analytic.txt" - impala shell code that joins lookup table calculated in "Crime Subway Distance Calc.txt" with additional crime and subway data and creates final view of all merged data to run queries on.  Contains all queries and output generated for analytic.
data_ingest
• "Data Ingest Steps.txt" - contains commands used to upload the data to Dumbo, unzip it, and put it into HDFS
etl_code
• "MR Jobs.txt" - contains text used to submit MR jobs for ETL
• "clean_crime_map.py" - MR map program that selects desired columns only from crime data and reformats fields where required
• "clean_Crime_reduce.py" - prints the result from map program
• "subway_map.py" - MR map program that selects desired columns only from subway data and reformats fields where required
• "subway_reduce.py" - prints the result from map program
profiling_code
• "Profiling Jobs Submitted.txt" - contains text used to submit MR jobs for Profiling
• "count_records_map.py" - prints each ID value
• "count_records_reduce.py" - sums up count of total IDs
• "geo_len_map.py" - summarizes character length of geo field
• "location_map.py" - summarizes distinct station names
• "subwaylines_map.py" - summarizes distinct subway lines
• "subwayname_len_map.py" - summarizes character length of subway name field
• "subwayname_map.py" - summarizes distinct station names
• "general_reducer.py" - reducer for geo_len_map.py, location_map.py, subwaylines_map.py, subwayname_len_map.py, subwayname_map.py
screenshots
• "Sample Profiling 1.png" - shows example working MR program for profiling ("subwaylines_map.py", "general_reducer.py" files)
• "Sample Profiling 2.png" - shows example working MR program for profiling ("subwaylines_map.py", "general_reducer.py" files)
• "Distance Calculation.png" - shows working commands for calculating distance and creating lookup table (commands from "Crime Subway Distance Calc.txt" file)
• "Analytic.png" - shows working commands for performing final data merge and submitting sample SQL query with results (commands from "Impala Crime Analytic.txt" file)
• "Clean Crime MR 1.png" - shows example working MR program for cleaning crime data ("clean_crime_map.py", "clean_crime_reduce.py" files)
• "Clean Crime MR 2.png" - shows example working MR program for cleaning crime data ("clean_crime_map.py", "clean_crime_reduce.py" files)
• "Clean Subway MR.png" - shows example working MR program for cleaning subway data ("subway_map.py", "subway_reduce.py" files)
test_code
• "Old Crime MR Programs" - folder containing old Java versions of MR crime cleaning program
• "distance calc spark version v2.txt" - version of distance calculation implemented in Spark.  Impala took some time for me to get working due to confusion with user tables so I first implemented in Spark, then redid it in Impala for the final version.
• "outputs.txt" - additional Impala SQL queries and their output run on data that wasn't cleaned 100% correctly first 

-----------------------------------------------------------------------------------------------------------------------------------------------------------

STEP BY STEP DETAIL OF HOW THE CODE WAS RUN:
After downloading data from NYC Open Data and uploading to Dumbo using the steps in "Data Ingest Steps.txt" file we had 2 data files in HDFS:
hdfs:/user/ctd299/NYPD_Complaint_Data_Historic(1).csv
hdfs:/user/ctd299/DOITT_SUBWAY_STATION_01_13SEPT2010_1.csv

1) Data cleaning
Program files for running MR cleaning job on crime data:
hdfs:/user/ctd299/clean_crime_map.py
hdfs:/user/ctd299/clean_crime_reduce.py

Program files for running MR cleaning job on subway data:
hdfs:/user/ctd299/subway_map.py
hdfs:/user/ctd299/subway_reduce.py

MR job to clean crime data:
hadoop jar /opt/cloudera/parcels/CDH/lib/hadoop-mapreduce/hadoop-streaming.jar -D mapreduce.job.reduces=32 -files hdfs://dumbo/user/ctd299/clean_crime_map.py,hdfs://dumbo/user/ctd299/clean_crime_reduce.py -mapper "python clean_crime_map.py" -reducer "python clean_crime_reduce.py" -input "/user/ctd299/NYPD_Complaint_Data_Historic(1).csv" -output /user/ctd299/MR_cleaned_crime

MR job to clean subway data:
hadoop jar /opt/cloudera/parcels/CDH/lib/hadoop-mapreduce/hadoop-streaming.jar -D mapreduce.job.reduces=1 -files hdfs://dumbo/user/ctd299/subway_map.py,hdfs://dumbo/user/ctd299/subway_reduce.py -mapper "python subway_map.py" -reducer "python subway_reduce.py" -input /user/ctd299/DOITT_SUBWAY_STATION_01_13SEPT2010_1.csv -output /user/ctd299/MR_cleaned_subway

Final files produced from MR cleaning:
hdfs:/user/ctd299/MR_cleaned_crime
hdfs:/user/ctd299/MR_cleaned_subway

2) Analytic
Run commands in "Crime Subway Distance Calc.txt" to create a lookup table in Impala with crime ID, subway ID, distance to closest subway, and name of closest subway 

Next run commands in "Impala Crime Analytic.txt" to merge lookup table with additional crime and station fields to generate final table in Impala.  Once final table is generated run queries in file in Impala shell to generate data tables.  For convenience, data tables outputted by Impala are pasted back into .txt file.