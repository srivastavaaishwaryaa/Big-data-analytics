import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.OutputCollector;
import java.io.*;
import java.util.Arrays;
import java.io.BufferedReader;
import java.util.Iterator;
public class CrimeCleaner
{
public static void main(String [] args) throws Exception
{
JobConf conf = new JobConf(CrimeCleaner.class);
conf.setNumReduceTasks(1);
conf.setJobName("CrimeCleaner");
FileInputFormat.addInputPath(conf, new Path(args[0]));
FileOutputFormat.setOutputPath(conf, new Path(args[1]));
conf.setJarByClass(CrimeCleaner.class);
conf.setMapperClass(MapForCrimeCleaner.class);
conf.setReducerClass(ReduceForCrimeCleaner.class);
conf.setOutputKeyClass(IntWritable.class);
conf.setOutputValueClass(Text.class);
JobClient.runJob(conf);
}
}
class MapForCrimeCleaner extends MapReduceBase implements Mapper<LongWritable, Text, IntWritable, Text>{
public static final String COMMA=",";
public static final String SPACE=" ";

public void map(LongWritable key, Text value, OutputCollector<IntWritable, Text> output, Reporter reporter) throws IOException
{
//inside mapper method
String line = value.toString(); 
String cols[]=line.split(COMMA);
if (cols!=null && cols.length>=34){
if(cols[13]!=null && cols[32]!=null && cols[33]!=null){  
String crime_type=cols[13];
CRIME_TYPE crimeType;
try{
   crimeType=CRIME_TYPE.valueOf(crime_type!=null?crime_type.toUpperCase():"");
//         xt
//         *we are only considering for crime types under CRIME_TYPE*/
output.collect(new IntWritable(crimeType.ordinal()), new Text(new StringBuilder(cols[34]).toString()));
                       }catch(Exception rte)
{
output.collect(new IntWritable(-1), new Text(new StringBuilder("ERROR: Unknown crime type encountered. Ignoring this record :").append(crime_type).append(", complaint: ").append(cols[0]).toString()));
 }
 }
 }
 else{

output.collect(new IntWritable(-1), new Text(new StringBuilder("SEVERE: File has insufficient fields ").append(Arrays.toString(cols)).toString()));
}
}
}
enum CRIME_TYPE{
FELONY,
VOILATION,
MISDEMEANOR
};

class ReduceForCrimeCleaner extends MapReduceBase implements Reducer<IntWritable, Text, IntWritable, Text>
{
public void reduce(IntWritable key, Iterator<Text> values, OutputCollector<IntWritable, Text> output, Reporter reporter) throws IOException{
int sum =0;

if (key.get()==CRIME_TYPE.FELONY.ordinal()){

//plot the work for FELONY}
//
}
else if (key.get()==CRIME_TYPE.VOILATION.ordinal()){

////plot the work for VOILATION
}
else if (key.get()==CRIME_TYPE.MISDEMEANOR.ordinal()){

////plot the work for MISDEMEANOR
}
output.collect(key, values.next());
}
}

