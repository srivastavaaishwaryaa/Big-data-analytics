#!/usr/bin/env python

#This file is used to clean and transform the subway data
import sys


for line in sys.stdin:
	if "OBJECTID" not in line: #skip the header row
		listvals=line.split(",")
		objectid=listvals[1]
		name=listvals[2]
		geom=listvals[3].replace("(","").replace(")","")
		latitude=geom.split(" ")[1]
		longitude=geom.split(" ")[2]
		subwayline=listvals[4]
		print(objectid+","+name+","+latitude+","+longitude+","+subwayline)