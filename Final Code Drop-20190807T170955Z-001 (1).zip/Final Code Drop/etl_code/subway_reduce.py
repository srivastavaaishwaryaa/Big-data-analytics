#!/usr/bin/env python

#This file is used to clean and transform the subway data
import sys

for line in sys.stdin:
	print(line)