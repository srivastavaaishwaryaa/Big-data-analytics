#!/usr/bin/env python

#This file is used to clean and transform the crime data
import sys

for line in sys.stdin:
	listvals=line.split(",")
	CMPLNT_NUM=listvals[0]
	year=listvals[1][-4:] #get the year only
	OFNS_DESC=listvals[8].replace(",","") #remove columns from offense description
	PD_DESC=listvals[10].replace(",","") #remove columns from PD description
	CRM_ATPT_CPTD_CD=listvals[11]
	LAW_CAT_CD=listvals[12]
	BORO_NM=listvals[13]
	Latitude=listvals[27]
	Longitude=listvals[28]
	STATION_NAME=listvals[31]
	print(CMPLNT_NUM+","+year+","+OFNS_DESC+","+PD_DESC+","+CRM_ATPT_CPTD_CD+","+LAW_CAT_CD+","+BORO_NM+","+Latitude+","+Longitude+","+STATION_NAME)